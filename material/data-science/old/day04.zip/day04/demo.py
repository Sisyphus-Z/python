import numpy as np
import matplotlib.pyplot as plt

x = np.arange(1, 8)
y = np.array([18, 23, 6, 14, 3, 19, 11])
plt.plot(x, y)
plt.show()